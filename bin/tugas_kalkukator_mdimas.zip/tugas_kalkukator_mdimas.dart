class kalkulator {
  double number1;
  double number2;
  kalkulator(this.number1, this.number2);

  double pertambahan(number1, number2) {
    return number1 + number2;
  }

  double pengurangan(number1, number2) {
    return number1 - number2;
  }

  double perkalian(number1, number2) {
    return number1 * number2;
  }

  double pembagian(number1, number2) {
    return number1 / number2;
  }
}
